document.addEventListener('DOMContentLoaded', function() {
	AOS.init();
}, false);