module.exports = {
    // Database
    database: {
        connectionLimit: 10,
        host: '127.0.0.1',
        user: 'Jorge',
        password: '$pass123',
        database: 'LuckyDB',
        port: "3306"
    }
};